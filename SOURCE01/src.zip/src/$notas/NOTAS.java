package $notas;

public class NOTAS {
 /*
  --> mvc LISTO CON METODOS EN MODELO
  		-Generar modelos
  			Ficha [+]
  		 	Coleccion [+]
  		 	Caja [+]
  		- Generar documentos vistas
  			GENprincipal[+]
  			Ficha [+]
  		 	Coleccion [+]
  		 	Caja [+]
  		- generar documentos controladores
  			Ficha [+ ,falta actionPerform]
  		 	Coleccion [+,falta actionPerform]
  		 	Caja [+ ,falta actionPerform]
  		- CONECTAR vista - contolador
  		 	Ficha [+]
  		 	Coleccion [+]
  		 	Caja [+]
  		
  		- diseñar metodos crud del modelo  "Study App"[+]
  		
  		- diseñar dao
  			-Recoger metodos del crud en "Study App"
  		
  		- enlazar documentos DAO - MODELO "Study App"
  			
  		- diseñar vistas visualmente
  		
  		
  --> CRUD
  
  		- Funcional en Ficha
  		- Funcional en Caja
  		- Funcional en Colecciones
  		
  		
  --> exportar importar (NO HACE FALTA)
  --> BBDD SQL
 
  * */
}
