package ies.piobaroja.dam2.accesoadatos.studyapp.dao;


public class DAO_StudyApp {
	private static DAO_StudyApp instancia=null;
	
	
	private DAO_StudyApp() {
		
	}
	
	/*
	 	private static DAOMensajeria instancia=null;
	
	private Mensajeria mensajeria;
	
	private DAOMensajeria() {
		mensajeria=new Mensajeria();
	}
	
	public static DAOMensajeria getInstancia() {
		if (instancia==null) {
			instancia=new DAOMensajeria();
		}
		return instancia;
	}
	
	
	 
	 **/
}
